import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indianenglish',
  templateUrl: './indianenglish.component.html',
  styleUrls: ['./indianenglish.component.scss']
})
export class IndianenglishComponent implements OnInit {
	public inputHasValue=false;
  public showLoader=false;
  public fileName="";
  public fileSize="";
  constructor() { }

  ngOnInit() {
  }
  getFileName(e){
  	this.showLoader=true;
  	setTimeout(()=>{
  		this.fileName = e.target.files[0].name;
  		this.fileSize = Math.floor((e.target.files[0].size)/1000000) + 'MB'	 ;
  		this.showLoader=false;
  		this.inputHasValue=true;
  	}
  		,2000);
  	
  }
}
