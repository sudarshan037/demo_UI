import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indianhindi',
  templateUrl: './indianhindi.component.html',
  styleUrls: ['./indianhindi.component.scss']
})
export class IndianhindiComponent implements OnInit {
  public inputHasValue=false;
  public showLoader=false;
  public fileName="";
  public fileSize="";

  constructor() { }

  ngOnInit() {
  }
  getFileName(e){
  	this.showLoader=true;
  	setTimeout(()=>{
  		this.fileName = e.target.files[0].name;
  		this.fileSize = Math.floor((e.target.files[0].size)/1000) + 'KB'	 ;
  		this.showLoader=false;
  		this.inputHasValue=true;
  	}
  		,2000);
  	
  }
}
